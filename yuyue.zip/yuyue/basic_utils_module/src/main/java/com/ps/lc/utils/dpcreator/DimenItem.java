package com.ps.lc.utils.dpcreator;

/**
 * 类名：DimenItem
 * 描述：dimens文件中的dimen数据项
 *
 * @author liucheng - liucheng@xhg.com
 * @date 2019/2/14 17:45
 */
public class DimenItem {
    public String name;
    public String value;
}
