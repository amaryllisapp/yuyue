package com.ps.lc.utils.shared;

/**
 * Created by substring on 2016/8/3.
 * Email：zhangxuan@feitaikeji.com
 */
public class SharedKeyDef {

    public static final String KEY_START_TIME = "start_time";



}
